# CS562 Project Demo

This is basic demo code we wrote during lecture #2 on 3/30/23. Logic is hardcoded for a basic SQL query containing a where clause. The query is executed and the results are displayed in a table.

Feel free to use this as the basis for your project. You can use this code as a starting point and modify it to fit your needs.

**Note:** Don't forget to copy .env.example to .env and update the values to match your environment.

predicates has to be numbers, start with 1
comparison operators has to be matched to python !=, ==, >, <, >=, <=
limited to 5 basic aggregate functions
meet_conditions might not scale for other database, but for sales it's fine
limited input checking
